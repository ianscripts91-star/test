import http from 'http';

console.log('Initializing Discord Selfbot...');

const PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Bot is running natively on Railway.\n');
}).listen(PORT, () => {
  console.log(`Uptime check layer listening on port ${PORT}`);
});
